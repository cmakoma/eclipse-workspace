// Assignement LabBalloon
// Program Size
// Author Christian Makoma
// Created Oct 9, 2019


package labBalloon;

public enum Size {
	XS, S, M, L, XL
}
