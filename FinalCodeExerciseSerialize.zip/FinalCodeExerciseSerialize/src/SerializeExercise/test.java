// Assignement FinalCodeExerciseSerialize
// Program test
// Author Christian Makoma
// Created Dec 9, 2019


package SerializeExercise;

public class test {

	public static void main(String[] args) {
		Serialize.serializedCollection();

	}

}
