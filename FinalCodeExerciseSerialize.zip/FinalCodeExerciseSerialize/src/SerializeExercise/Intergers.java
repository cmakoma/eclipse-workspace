// Assignement FinalCodeExerciseSerialize
// Program Intergers
// Author Christian Makoma
// Created Dec 9, 2019


package SerializeExercise;

public interface Intergers {

}
