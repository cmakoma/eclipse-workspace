package firstTry;

public class setup {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		System.out.println("We are setting up");
		System.out.println("let me know when you clone this");
	}

}
