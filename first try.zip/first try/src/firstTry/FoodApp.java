// Assignement first try
// Program FoodApp
// Author Christian Makoma
// Created Dec 4, 2019


package firstTry;

public class FoodApp {

	public static void main(String[] args) {
		Food pizza1 = new Food("Hawaiian Pizza", 10.99);
		Food pizza2 = new Food("Pepperoni pizza", 12.99);
		Food pizza3 = new Food("Veggie pizza", 14.99);
		
		Food burger1 = new Food("Cheese burger", 10.99);
		Food burger2 = new Food("Chicken burger", 12.99);
		Food burger3 = new Food("Fish burger", 14.99);
		
		Food taco1 = new Food("Fish taco",4.99);
		Food taco2 = new Food("Street taco", 2.99);
		Food taco3 = new Food("Veggie taco", 3.99);
		
		System.out.println(taco1.toString());
	
	}
	
	

}
