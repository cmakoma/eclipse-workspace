// Assignement 1410_Module04
// Program Doubles
// Author Christian Makoma
// Created Oct 16, 2019


package m04;

public interface Doubles {
	

}
