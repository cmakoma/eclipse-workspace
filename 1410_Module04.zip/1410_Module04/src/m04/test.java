// Assignement 1410_Module04
// Program test
// Author Christian Makoma
// Created Oct 16, 2019


package m04;

public class test {

	public static void main(String[] args) {
		
		Module04.demoCollection();

	}

}
